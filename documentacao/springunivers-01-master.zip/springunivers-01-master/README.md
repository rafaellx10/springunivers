# springunivers-01
Lista de Contatos explorando os conceitos de JPA - Mapeamento - HQL e Spring Data JPA
