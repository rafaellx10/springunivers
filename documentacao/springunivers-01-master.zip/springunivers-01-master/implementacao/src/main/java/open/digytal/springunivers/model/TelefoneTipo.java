package open.digytal.springunivers.model;

public enum TelefoneTipo {
	FIXO, //ORDEM=0
	CEL, //ORDEM=1
	
	; 
	
}
