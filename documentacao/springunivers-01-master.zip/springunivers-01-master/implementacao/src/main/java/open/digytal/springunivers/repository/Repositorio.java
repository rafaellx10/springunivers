package open.digytal.springunivers.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Component;

import open.digytal.springunivers.model.Cliente;
import open.digytal.springunivers.model.Contato;
import open.digytal.springunivers.model.Fornecedor;

@Component
public class Repositorio {
	@PersistenceContext
	private EntityManager em;

	public List<Contato> contatos() {
		return em.createQuery("SELECT e FROM Contato e").getResultList();
	}

	public List<Cliente> clientes() {
		return em.createQuery("SELECT e FROM Cliente e").getResultList();
	}

	// JPQL
	public List<Cliente> listarClientes(String nome) {
		Query query = em.createQuery("SELECT e FROM Cliente e WHERE e.nome LIKE :nome ");
		query.setParameter("nome", "%" + nome + "%");
		return query.getResultList();
	}

	// Criteria
	public List<Cliente> listarClientesCriteria(String nome) {
		CriteriaBuilder builder = em.getCriteriaBuilder();
		
		CriteriaQuery<Cliente> query = builder.createQuery(Cliente.class);
		
		Root<Cliente> from = query.from(Cliente.class);
		
		TypedQuery<Cliente> typedQuery = em.createQuery(
				query.select(from )
			    .where(
			       builder.like (from.get("nome"), "%" + nome + "%")
			    )
		);
		List<Cliente> clientes = typedQuery.getResultList();
		return clientes;
	}

	public List<Fornecedor> fornecedores() {
		return em.createQuery("SELECT e FROM Fornecedor e").getResultList();
	}
}
