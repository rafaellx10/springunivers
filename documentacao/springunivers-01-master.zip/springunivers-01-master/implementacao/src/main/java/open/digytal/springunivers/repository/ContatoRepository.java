package open.digytal.springunivers.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import open.digytal.springunivers.model.Contato;

public interface ContatoRepository extends JpaRepository<Contato, Integer> {

}
