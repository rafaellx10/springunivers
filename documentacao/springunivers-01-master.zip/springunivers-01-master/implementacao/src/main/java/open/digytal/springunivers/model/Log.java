package open.digytal.springunivers.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Embeddable
public class Log {
	@Temporal(TemporalType.DATE)
	@Column(name = "data_inclusao")
	private Date dataInclusao;
	@Temporal(TemporalType.DATE)
	@Column(name = "data_alteracao")
	private Date dataAlteracao;
	public Date getDataInclusao() {
		return dataInclusao;
	}
	public void setDataInclusao(Date dataInclusao) {
		this.dataInclusao = dataInclusao;
	}
	public Date getDataAlteracao() {
		return dataAlteracao;
	}
	public void setDataAlteracao(Date dataAlteracao) {
		this.dataAlteracao = dataAlteracao;
	}
	
	
}
