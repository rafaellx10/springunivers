package open.digytal.springunivers;

import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import open.digytal.springunivers.model.Cidade;
import open.digytal.springunivers.model.Cliente;
import open.digytal.springunivers.model.Contato;
import open.digytal.springunivers.model.Fornecedor;
import open.digytal.springunivers.model.Telefone;
import open.digytal.springunivers.repository.CidadeRepository;
import open.digytal.springunivers.repository.ClienteRepository;
import open.digytal.springunivers.repository.ContatoRepository;
import open.digytal.springunivers.repository.Repositorio;

@Component
public class SistemaAgenda {
	@Autowired
	private ContatoRepository repository;
	@Autowired
	private ClienteRepository clienteRepository;
	@Autowired
	private Repositorio repositorio;
	@Autowired
	private CidadeRepository cidadeRepository;
	
	private final int ID = new Random().nextInt(1000);
	
	public void listarContatos() {
		/*List<Contato> contatos = repositorio.contatos();
		System.out.println("Lista de Contatos...." + contatos.size());

		List<Cliente> clientes = repositorio.clientes();
		System.out.println("Lista de Clientes...." + clientes.size());

		List<Fornecedor> fornecedores = repositorio.fornecedores();
		System.out.println("Lista de Fornecedores...." + fornecedores.size());*/
		
		Cidade cidade = buscarCidade();
		
		//List<Cliente> clientes = clienteRepository.listarClientesLike("JOSE");
		//List<Cliente> clientes = clienteRepository.findByCidade(cidade);
		
		List<Cliente> clientes = repositorio.listarClientesCriteria("JOSE");
		
		clientes.forEach(c->{
			System.out.printf("NOME:%-20s SOBRENOME:%s\n",c.getNome(),c.getSobrenome());
			
			c.getTelefones().forEach(t->{
				System.out.println(t.getDdd() + " - " + t.getNumero());
			});
			
		});
		System.out.println("Total de clientes --> " + clientes.size());
	}

	/*
	 * public void criarContato() { Contato contato = new Contato();
	 * contato.setNome("CLIENTE"); contato.setSobrenome("TESTE");
	 * contato.setDdd(11); contato.setNumero(958940362L); repository.save(contato);
	 * 
	 * }
	 */
	public void criarCidade() {
		Cidade cidade = buscarCidade();
		if(cidade==null) {
			cidade = new Cidade();
			cidade.setIbge(2207702);
			cidade.setNome("PARNAIBA");
			cidade.setEstado("PI");
			cidadeRepository.save(cidade);
		}
	}
	private Cidade buscarCidade() {
		Optional<Cidade> optCidade = cidadeRepository.findById(2207702);
		Cidade cidade = optCidade.isPresent()?optCidade.get():null;
		return cidade;
	}
	public void criarCliente() {
		Cliente contato = new Cliente();
		contato.setNome("CLIENTE " + ID);
		contato.setSobrenome("F CAMARA "  + ID);
		contato.setUltimaCompra(new Date());
		contato.setValor(1250.33);
		
		contato.setCidade(buscarCidade());
		
		Telefone telefone = new Telefone();
		telefone.setDdd(11);
		telefone.setNumero(958940362L);
		contato.addTelefoneFixo(telefone);
		repository.save(contato);

	}
	public void criarClientes() {
		String[] nomes = new String[] {"FABIANO ","JOSE MENDES", "JOSE FERNANDES","JULIO FARIAS"};
		String[] sobrenome = new String[] {"MENDES","SANTOS", "ANDRADE","JUNIOR"};
		
		Long[] numeros = new Long[] {987809790l,781634778l, 194738209l,816379816l};

		Optional<Cidade> optCidade = cidadeRepository.findById(2207702);
		Cidade cidade = optCidade.isPresent()?optCidade.get():null;
		int x=0;
		for(String nome:nomes) {
			Cliente contato = new Cliente();
			contato.setNome(nome);
			contato.setSobrenome(sobrenome[x]);
			contato.setUltimaCompra(new Date());
			contato.setValor(1250.33);
			contato.setCidade(cidade);
			Telefone telefone = new Telefone();
			telefone.setDdd(11);
			telefone.setNumero(numeros[x++]);
			contato.addTelefoneFixo(telefone);
			repository.save(contato);
		}
		
	}
	public void alterarContato(Integer id, String nome) {
		Optional<Contato> opt = repository.findById(id);
		if(opt.isPresent()) {
			Contato contato = opt.get();
			contato.setNome(nome);
			repository.save(contato);
			System.out.println("Contato alterad com sucesso!!");
		}else
			System.out.println("Não localizamos nehum contato com ID " + id);
		
	}
	public void criarFornecedor() {
		Fornecedor contato = new Fornecedor();
		contato.setNome("FORNECEDOR " + ID);
		contato.setSobrenome("DELL "  + ID);
		contato.setUltimaVisita(new Date());
		contato.setCidade(buscarCidade());
		Telefone telefone = new Telefone();
		telefone.setDdd(11);
		telefone.setNumero(854684219L);
		contato.addTelefoneCelular(telefone);
		repository.save(contato);

	}
}
