package open.digytal.springunivers.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;

@Entity
@Table(name = "TB_CONTATO")
@Inheritance(strategy = InheritanceType.JOINED)
public abstract class Contato implements Serializable {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer id;
	@Column(length = 50, nullable = false)
	private String nome;
	@Column(length = 50, nullable = false)
	private String sobrenome;

	@ManyToOne
	@JoinColumn(name = "cd_cidade")
	private Cidade cidade;

	@OneToMany(cascade=CascadeType.PERSIST, mappedBy="contato", fetch=FetchType.EAGER)
	private List<Telefone> telefones;
	
	@Embedded
	private Log log;

	public Contato() {
		this.telefones = new ArrayList<Telefone>();
	}

	public List<Telefone> getTelefones() {
		return telefones;
	}

	public Cidade getCidade() {
		return cidade;
	}

	public void setCidade(Cidade cidade) {
		this.cidade = cidade;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getSobrenome() {
		return sobrenome;
	}

	public void setSobrenome(String sobrenome) {
		this.sobrenome = sobrenome;
	}
	public void addTelefoneCelular(Telefone telefone) {
		addTelefone(telefone, TelefoneTipo.CEL);
	}

	public void addTelefoneFixo(Telefone telefone) { 
		addTelefone(telefone,TelefoneTipo.FIXO);
	}

	public void addTelefone(Telefone telefone, TelefoneTipo tipo) {
		telefone.setContato(this);
		telefone.setTipo(tipo);
		this.telefones.add(telefone);
	}
	@PrePersist
	private void prePersist() {
		log = new Log();
		log.setDataInclusao(new Date());
	}
	@PreUpdate
	private void preUpdate() {
		log.setDataAlteracao(new Date());
	}

	@Override
	public String toString() {
		return "Contato [id=" + id + ", nome=" + nome + ", sobrenome=" + sobrenome + ", cidade=" + cidade
				+ ", telefones=" + telefones + ", log=" + log + "]";
	}
	
}
