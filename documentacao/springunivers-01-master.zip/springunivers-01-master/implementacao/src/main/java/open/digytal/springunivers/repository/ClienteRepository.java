package open.digytal.springunivers.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import open.digytal.springunivers.model.Cidade;
import open.digytal.springunivers.model.Cliente;

public interface ClienteRepository extends JpaRepository<Cliente, Integer> {
	List<Cliente> findByNome(String nome);
	
	@Query("select c from Cliente c where c.nome = :nome")
	List<Cliente> listarClientes(@Param("nome") String nome);
	
	@Query("select c from Cliente c where c.nome = ?1")
	List<Cliente> listarClientesParametro(String nome);
	
	
	List<Cliente> findByNomeContaining(String nome);
	
	@Query("select c from Cliente c where c.nome like %:nome%")
	List<Cliente> listarClientesLike(@Param("nome") String nome);
	
	List<Cliente> findByCidade(Cidade cidade);
	
		
}
