<template lang="html">

  <section class="popovers">
    <h1>popovers Component</h1>
  </section>

</template>

<script lang="js">
export default {
  name: 'popovers'
}
</script>

<style scoped lang="scss">
.popovers {

}
</style>
